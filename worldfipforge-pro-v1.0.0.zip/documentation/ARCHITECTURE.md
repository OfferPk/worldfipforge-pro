# WorldFIPForge Pro - Technical Architecture & Protocol Specification

## 1. Executive Summary & Purpose
**WorldFIPForge Pro** is a mission-critical industrial fieldbus protocol engineering suite designed for **WorldFIP (EN 50170-3 / IEC 61158-6 / NFC 46-602)** networks. WorldFIP serves as the underlying real-time communication backbone in Europe's most safety-critical infrastructures:
- **High-Speed Passenger Rail**: French TGV (TGV POS, Duplex, Eurostar), Alstom AGATE train control networks, and metros.
- **Nuclear Power Generation**: Électricité de France (EDF) reactor instrumentation and control (N4, EPR).
- **Particle Physics Research**: CERN Large Hadron Collider (LHC) cryogenic control, radiation-hardened beam instrumentation, and magnet quench protection.

### Solved Engineering Challenges:
1. **Producer-Consumer-Distributor (PCD) Architecture**: Unlike master/slave polling where requests and responses pass point-to-point, WorldFIP broadcasts 16-bit Variable Identifiers (`VarID`) via a central **Bus Arbitrator (BA)**. The designated producer broadcasts the response data (`RP_DAT`), and any number of consumers simultaneously latch the value without extra bus overhead.
2. **Deterministic Macrocycle Scheduling**: Sequences Elementary Cycles (EC) to ensure high-priority cyclic variables (traction speed, brake cylinder pressures) are guaranteed jitter-free transmission slots, while strictly reserving $\ge 20\%$ bandwidth for aperiodic messaging (`ID_MSG`, `RP_MSG`).
3. **Physical Layer Line Sizing**: Enforces $150\ \Omega$ shielded twisted-pair impedance matching, line attenuation budgets, and $10\text{m}$ drop line limits across $31.25\text{ kbps}$, $1.0\text{ Mbps}$, $2.5\text{ Mbps}$, and $5.0\text{ Mbps}$ profiles.
4. **10-Point Safety Auditor**: Evaluates VarID collision risks, dual $150\ \Omega$ termination validity, cable budgets, transceiver electrical loads (max 32 nodes), and redundant Bus Arbitrator (BA) readiness.
5. **Multi-Target Exporter**: Generates Alstom Agate Train Control variable CSV tables, MicroFIP / FullFIP C header definitions (`.h`), and Python 3 Bus Arbitrator simulation scripts.

---

## 2. Standards & Physical Layer Specifications
- **EN 50170-3 / NFC 46-602 / NFC 46-604**: General Purpose Field Communication System Part 3 (WorldFIP).
- **IEC 61158-6**: Industrial communication networks — Fieldbus specifications (Type 7).
- **Physical Signaling**: Manchester Biphase-L, transformer-coupled differential signaling over $150\ \Omega$ shielded twisted pair.
- **Transmission Rates**:
  - $31.25\text{ kbps}$ (1900m trunk, process automation)
  - $1.0\text{ Mbps}$ (1000m trunk, TGV rolling stock and nuclear control)
  - $2.5\text{ Mbps}$ (500m trunk, CERN LHC cryogenics & beam lines)
  - $5.0\text{ Mbps}$ (200m trunk, ultra-high-speed substations)
- **Termination**: Exactly two $150\ \Omega \pm 1\%$ resistors at physical trunk endpoints ($75\ \Omega$ net DC load).

---

## 3. Physical Framing & Delimiters
WorldFIP frames utilize non-data symbols in Manchester encoding for robust hardware frame boundaries:
```
+----------+----+---------+----------------------+--------+----+
| Preamble | SD | Control | Variable Data / PDU | CRC-16 | ED |
+----------+----+---------+----------------------+--------+----+
  2 bytes   1B     1B            Variable         2 bytes  1B
```
- **Preamble**: `0x55 0x55` (Alternating bit clock synchronization)
- **Start Delimiter (SD)**: `0x1E`
- **End Delimiter (ED)**: `0xE1`
- **Control Field**:
  - `0x03` = `ID_DAT` (Question broadcast by Bus Arbitrator for a variable)
  - `0x05` = `RP_DAT` (Response broadcast by the producing subscriber)
  - `0x04` = `ID_RQ` (Arbitrator aperiodic query)
  - `0x06` = `RP_RQ` (Node aperiodic announcement)
  - `0x07` = `ID_MSG` (Aperiodic message transfer)
  - `0x08` = `RP_MSG` (Aperiodic message acknowledgment)
- **CRC-16 FCS**: CCITT-False polynomial $x^{16} + x^{12} + x^5 + 1$ (`0x1021`), Initial value `0xFFFF`, Final XOR `0xFFFF`.

---

## 4. Bus Arbitrator (BA) Elementary Cycle Mathematical Model

In an Elementary Cycle of duration $T_{\text{EC}}$ (typically $5\text{ ms}$ or $10\text{ ms}$), the total periodic transmission time $T_{\text{periodic}}$ for $N$ scheduled variables is:

$$T_{\text{transaction}, i} = T_{\text{ID\_DAT}} + T_r + T_{\text{RP\_DAT}, i} + T_r$$

Where:
- $T_{\text{ID\_DAT}} = \frac{72\text{ bits}}{\text{Baud Rate}}$ ($72\ \mu\text{s}$ at $1.0\text{ Mbps}$)
- $T_r$ = Response turnaround silence time ($20\ \mu\text{s}$ at $1.0\text{ Mbps}$, $80\ \mu\text{s}$ at $31.25\text{ kbps}$)
- $T_{\text{RP\_DAT}, i} = \frac{(64 + 8 \times \text{DataBytes}_i)\text{ bits}}{\text{Baud Rate}}$
- $T_{\text{periodic}} = \sum_{i=1}^{N} T_{\text{transaction}, i}$

The aperiodic time available for background messaging and diagnostics is:
$$T_{\text{aperiodic}} = T_{\text{EC}} - T_{\text{periodic}}$$

To ensure reliable, deterministic operation without jitter or message starvation, the periodic load must satisfy $\frac{T_{\text{periodic}}}{T_{\text{EC}}} \le 80\%$.

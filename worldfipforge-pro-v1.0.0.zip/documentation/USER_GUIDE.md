# WorldFIPForge Pro - User Guide & Operator Manual

## 1. Quick Start
To launch the interactive web studio:
1. Open `product_198/source-code/index.html` in any modern web browser.
2. All calculations and protocol dissections execute client-side with zero external internet dependencies or backend installations.

To use the standalone Python CLI:
```bash
# Make CLI executable
chmod +x product_198/build/worldfip-cli.py

# Build an ID_DAT Bus Arbitrator Question Frame for Variable 0x1001
./product_198/build/worldfip-cli.py id-dat --var 0x1001

# Build an RP_DAT Producer Data Frame for Variable 0x1001
./product_198/build/worldfip-cli.py rp-dat --var 0x1001 --status 0x00

# Dissect a raw WorldFIP hex frame
./product_198/build/worldfip-cli.py dissect "55 55 1E 03 10 01 79 61 E1"

# Calculate Bus Arbitrator Macrocycle schedule
./product_198/build/worldfip-cli.py schedule --vars '[{"id":4097,"bytes":4},{"id":4098,"bytes":4}]' --ec 10 --baud 1000

# Run 10-Point Safety Auditor
./product_198/build/worldfip-cli.py audit --vars '[{"id":4097,"bytes":4},{"id":4098,"bytes":4}]' --stations '[{"name":"Cab A","drop":2.5,"ba":true},{"name":"Traction 1","drop":4.0}]' --trunk 600 --speed 1000
```

---

## 2. Workbench Tabs & Capabilities

### Tab 1: ID_DAT / RP_DAT Frame Studio
- Compose Bus Arbitrator questions (`ID_DAT`, `0x03`) and Producer responses (`RP_DAT`, `0x05`).
- Configure 16-bit Variable Identifiers (`VarID`), PDU Status bytes (`0x00` Fresh/Valid, `0x80` Stale/Invalid, `0x82` Device Fault), and variable payload bytes.
- Inspects and validates hardware CCITT-False CRC-16 Frame Check Sequences.

### Tab 2: Bus Arbitrator Macrocycle Scheduler
- Configure cyclic process variables with designated producing stations, periods (10ms, 20ms, 50ms), and payload sizes.
- Sequences Elementary Cycles (EC) and visualizes periodic duration versus aperiodic diagnostic slots.
- Monitors overall bus utilization and ensures $\ge 20\%$ aperiodic headroom.

### Tab 3: 150-Ohm Physical Sizer
- Select baud rate (31.25 kbps, 1.0 Mbps, 2.5 Mbps, 5.0 Mbps) and enter physical trunk distance.
- Computes cable propagation delay (5.0 ns/m), total cable length (trunk + drops), and estimated attenuation loss in dB ($< 15\text{ dB}$ margin).
- Validates station transceiver counts against physical load limits.

### Tab 4: 10-Point Safety Auditor
- Pre-commissioning verification:
  - 16-bit VarID collision checks.
  - Unique producer assignment under the PCD model.
  - Dual 150-ohm line terminators (75-ohm net differential load).
  - Physical trunk and individual drop line limits ($10\text{m}$ max at 1.0 Mbps, $5\text{m}$ max at 2.5 Mbps).
  - Elementary cycle periodic overruns.
  - 32-station transceiver limits.
  - Turnaround silence time ($T_r \ge 20\ \mu\text{s}$) and Redundant Bus Arbitrator readiness.

### Tab 5: MicroFIP / Alstom Exporter
- Outputs Alstom Agate Train Control Variable CSV tables.
- Generates MicroFIP / FullFIP C header definitions (`.h`).
- Outputs Python 3 WorldFIP Bus Arbitrator simulation scripts.

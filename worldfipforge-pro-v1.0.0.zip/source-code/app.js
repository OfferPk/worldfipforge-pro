/**
 * WorldFIPForge Pro - Web Application Controller
 */

document.addEventListener('DOMContentLoaded', function () {
  // Navigation Tabs
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));

      btn.classList.add('active');
      const targetId = btn.getAttribute('data-tab');
      document.getElementById(targetId).classList.add('active');
    });
  });

  // Default Datasets
  let variables = [
    { varId: 0x1001, name: 'Train Speed Measurement', periodMs: 10, producer: 'Traction Unit 1', dataBytes: 4 },
    { varId: 0x1002, name: 'Brake Cylinder Pressure', periodMs: 10, producer: 'Brake Unit 1', dataBytes: 4 },
    { varId: 0x2001, name: 'Pantograph Contact Status', periodMs: 20, producer: 'High-Voltage Unit', dataBytes: 2 },
    { varId: 0x3001, name: 'Passenger Coach Temperature', periodMs: 50, producer: 'HVAC Unit', dataBytes: 8 }
  ];

  let stations = [
    { stationId: 1, name: 'Cab A Driver Display (BA)', dropLengthM: 2.5, isBa: true },
    { stationId: 2, name: 'Traction Converter 1', dropLengthM: 4.0, isBa: false },
    { stationId: 3, name: 'Brake Control Unit', dropLengthM: 3.5, isBa: false },
    { stationId: 4, name: 'Auxiliary Power Converter', dropLengthM: 5.0, isBa: false },
    { stationId: 5, name: 'Cab B Driver Display (Backup BA)', dropLengthM: 2.0, isBa: true }
  ];

  // TAB 1: Frame Dissector & Builder
  const frameTypeSelect = document.getElementById('frame-type-select');
  const groupRpDatParams = document.getElementById('group-rp-dat-params');

  frameTypeSelect.addEventListener('change', () => {
    if (frameTypeSelect.value === 'RP_DAT') {
      groupRpDatParams.style.display = 'block';
    } else {
      groupRpDatParams.style.display = 'none';
    }
  });

  function renderFipFrame() {
    const ftype = document.getElementById('frame-type-select').value;
    const varIdStr = document.getElementById('frame-var-id').value;
    const varId = varIdStr.startsWith('0x') || varIdStr.startsWith('0X') ? parseInt(varIdStr, 16) : parseInt(varIdStr, 10);

    let frameRes;
    const tbody = document.getElementById('dissect-tbody');

    if (ftype === 'ID_DAT') {
      frameRes = WorldFIPEngine.buildIdDatFrame(varId);
      document.getElementById('fip-hex-output').innerText = frameRes.hexString;
      document.getElementById('frame-byte-len-badge').innerText = `${frameRes.byteLength} Bytes`;

      tbody.innerHTML = `
        <tr><td>Preamble &amp; SD</td><td>0x5555 0x1E</td><td>Preamble (2 Bytes) + Start Delimiter (0x1E)</td></tr>
        <tr><td>Control Field</td><td>${frameRes.controlByte}</td><td>ID_DAT (Question from Bus Arbitrator)</td></tr>
        <tr><td>VarID</td><td>${frameRes.varIdHex} (${frameRes.varId})</td><td>16-Bit Variable Identifier</td></tr>
        <tr><td>CRC-16 FCS</td><td>${frameRes.crc}</td><td>CCITT-False Polynomial (0x1021) Valid</td></tr>
        <tr><td>End Delimiter</td><td>0xE1</td><td>Standard WorldFIP End Delimiter</td></tr>
      `;
    } else {
      const pduStatus = parseInt(document.getElementById('frame-pdu-status').value, 16) || 0;
      const dataStr = document.getElementById('frame-payload-data').value;
      const dataBytes = dataStr.split(',').map(s => {
        const t = s.trim();
        return t.startsWith('0x') || t.startsWith('0X') ? parseInt(t, 16) : parseInt(t, 10);
      }).filter(n => !isNaN(n));

      frameRes = WorldFIPEngine.buildRpDatFrame(varId, dataBytes, pduStatus);
      document.getElementById('fip-hex-output').innerText = frameRes.hexString;
      document.getElementById('frame-byte-len-badge').innerText = `${frameRes.byteLength} Bytes`;

      tbody.innerHTML = `
        <tr><td>Preamble &amp; SD</td><td>0x5555 0x1E</td><td>Preamble (2 Bytes) + Start Delimiter (0x1E)</td></tr>
        <tr><td>Control Field</td><td>${frameRes.controlByte}</td><td>RP_DAT (Producer Response Data)</td></tr>
        <tr><td>PDU Status</td><td>${frameRes.pduStatus}</td><td>Freshness &amp; Validity Flag</td></tr>
        <tr><td>Payload Data</td><td>${dataBytes.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ')}</td><td>${dataBytes.length} Data Bytes</td></tr>
        <tr><td>CRC-16 FCS</td><td>${frameRes.crc}</td><td>CCITT-False Polynomial (0x1021) Valid</td></tr>
        <tr><td>End Delimiter</td><td>0xE1</td><td>Standard WorldFIP End Delimiter</td></tr>
      `;
    }
  }

  document.getElementById('btn-build-fip-frame').addEventListener('click', renderFipFrame);

  // TAB 2: Macrocycle Scheduler
  function renderVarsTable() {
    const tbody = document.getElementById('tbody-vars');
    tbody.innerHTML = '';

    variables.forEach((v, idx) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><input type="text" class="form-control" style="width: 80px;" value="0x${v.varId.toString(16).toUpperCase()}" onchange="updateVar(${idx}, 'varId', this.value)"></td>
        <td><input type="text" class="form-control" value="${v.name}" onchange="updateVar(${idx}, 'name', this.value)"></td>
        <td><input type="number" class="form-control" style="width: 70px;" value="${v.periodMs}" onchange="updateVar(${idx}, 'periodMs', this.value)"></td>
        <td><input type="text" class="form-control" value="${v.producer}" onchange="updateVar(${idx}, 'producer', this.value)"></td>
        <td><input type="number" class="form-control" style="width: 70px;" value="${v.dataBytes}" onchange="updateVar(${idx}, 'dataBytes', this.value)"></td>
        <td><button class="btn btn-secondary" style="padding: 4px 8px; color: var(--red-accent);" onclick="removeVar(${idx})">✕</button></td>
      `;
      tbody.appendChild(tr);
    });

    renderSchedule();
  }

  window.updateVar = function (idx, field, val) {
    if (field === 'varId') {
      variables[idx][field] = val.startsWith('0x') || val.startsWith('0X') ? parseInt(val, 16) : parseInt(val, 10);
    } else if (field === 'periodMs' || field === 'dataBytes') {
      variables[idx][field] = parseInt(val) || 10;
    } else {
      variables[idx][field] = val;
    }
    renderSchedule();
  };

  window.removeVar = function (idx) {
    if (variables.length > 1) {
      variables.splice(idx, 1);
      renderVarsTable();
    }
  };

  document.getElementById('btn-add-var').addEventListener('click', () => {
    const nextId = 0x1000 + variables.length + 1;
    variables.push({
      varId: nextId,
      name: `Sensor Variable ${nextId.toString(16).toUpperCase()}`,
      periodMs: 20,
      producer: 'Station 2',
      dataBytes: 4
    });
    renderVarsTable();
  });

  function renderSchedule() {
    const sched = WorldFIPScheduler.buildMacrocycle(variables, 10, 1000);

    document.getElementById('stat-macrocycle').innerText = `${sched.macrocycleMs} ms`;
    document.getElementById('stat-avg-load').innerText = `${sched.summary.avgLoadPercent}%`;
    document.getElementById('stat-headroom').innerText = `${sched.summary.aperiodicHeadroomPercent}%`;

    const tbody = document.getElementById('tbody-ec');
    tbody.innerHTML = '';

    sched.elementaryCycles.forEach(ec => {
      const tr = document.createElement('tr');
      const varNames = ec.variables.map(v => `${v.name} (${v.varIdHex})`).join(', ') || 'Idle (Aperiodic Window)';
      tr.innerHTML = `
        <td><strong>EC ${ec.ecIndex}</strong></td>
        <td>${ec.timeOffsetMs} ms</td>
        <td style="font-size: 12px; color: var(--text-secondary);">${varNames}</td>
        <td>${ec.periodicDurationMs} ms</td>
        <td style="color: var(--emerald-accent);">${ec.aperiodicSlotMs} ms</td>
        <td style="font-weight: 600; color: ${ec.loadPercent > 80 ? 'var(--red-accent)' : 'var(--blue-accent)'};">${ec.loadPercent}%</td>
      `;
      tbody.appendChild(tr);
    });

    recalculatePhysical();
  }

  document.getElementById('btn-recalc-sched').addEventListener('click', renderSchedule);

  // TAB 3: Physical Sizer
  function recalculatePhysical() {
    const speed = document.getElementById('phy-speed').value;
    const trunkM = parseInt(document.getElementById('phy-trunk-len').value) || 600;

    const res = WorldFIPPhysicalSizer.evaluatePhysicalSegment(trunkM, stations, speed);

    document.getElementById('stat-phy-propagation').innerText = `${res.roundTripPropagationUs} µs`;
    document.getElementById('stat-phy-loss').innerText = `${res.estimatedLossDb} dB`;
    document.getElementById('stat-phy-total-cable').innerText = `${res.totalCableLengthM} m`;
  }

  document.getElementById('btn-recalc-phy').addEventListener('click', recalculatePhysical);
  document.getElementById('phy-speed').addEventListener('change', recalculatePhysical);

  // TAB 4: Safety Auditor
  function runAudit() {
    const speed = document.getElementById('phy-speed').value;
    const trunkM = parseInt(document.getElementById('phy-trunk-len').value) || 600;

    const auditRes = WorldFIPAuditor.auditNetwork({
      variables,
      stations,
      trunkLengthM: trunkM,
      speedKey: speed,
      terminatorsInstalled: 2,
      elementaryCycleMs: 10,
      hasRedundantBa: true
    });

    document.getElementById('audit-score').innerText = `${auditRes.summary.overallScore}/100`;
    document.getElementById('audit-grade').innerText = auditRes.summary.grade;
    document.getElementById('audit-summary-counts').innerText =
      `${auditRes.summary.passCount} Pass / ${auditRes.summary.warnCount} Warn / ${auditRes.summary.failCount} Fail`;

    const container = document.getElementById('audit-results-container');
    container.innerHTML = '';

    auditRes.findings.forEach(f => {
      const rule = auditRes.rules.find(r => r.id === f.id);
      const item = document.createElement('div');
      item.className = 'audit-item';

      let statusClass = 'audit-pass';
      if (f.status === 'WARN') statusClass = 'audit-warn';
      if (f.status === 'FAIL') statusClass = 'audit-fail';

      item.innerHTML = `
        <span class="audit-status ${statusClass}">${f.status}</span>
        <div class="audit-content">
          <h4>[${f.id}] ${rule ? rule.name : f.id} (${rule ? rule.standard : 'STD'})</h4>
          <p>${f.details}</p>
        </div>
      `;
      container.appendChild(item);
    });
  }

  document.getElementById('btn-run-audit').addEventListener('click', runAudit);

  // TAB 5: Exporter
  document.getElementById('btn-generate-export').addEventListener('click', () => {
    const target = document.getElementById('export-target').value;
    let out = '';

    if (target === 'ALSTOM_AGATE') {
      out = `# Alstom Agate Train Control Variable Table\nVarID_Hex,VarID_Dec,Name,Period_ms,Producer,Bytes\n`;
      variables.forEach(v => {
        out += `0x${v.varId.toString(16).toUpperCase()},${v.varId},"${v.name}",${v.periodMs},"${v.producer}",${v.dataBytes}\n`;
      });
    } else if (target === 'MICROFIP_HEADER') {
      out = `/* MicroFIP / FullFIP Variable Identifiers Header */\n#ifndef WORLDFIP_VARS_H\n#define WORLDFIP_VARS_H\n\n`;
      variables.forEach(v => {
        const cleanName = v.name.replace(/[^a-zA-Z0-9_]/g, '_').toUpperCase();
        out += `#define VAR_${cleanName} 0x${v.varId.toString(16).toUpperCase()}\n`;
      });
      out += `\n#endif /* WORLDFIP_VARS_H */\n`;
    } else if (target === 'PYTHON_SIM') {
      out = `#!/usr/bin/env python3\n# Python 3 WorldFIP Bus Arbitrator Simulator\nimport struct\n\n`;
      out += `def send_id_dat(var_id=0x1001):\n`;
      out += `    # ID_DAT: Preamble (0x5555) + SD (0x1E) + Ctrl (0x03) + VarID (16-bit)\n`;
      out += `    frame = struct.pack('>BBBH', 0x55, 0x55, 0x1E, 0x03) + struct.pack('>H', var_id)\n`;
      out += `    print(f"Broadcasting ID_DAT for Var 0x{var_id:04X}...")\n`;
      out += `    return frame\n\n`;
      out += `send_id_dat(0x1001)\n`;
    }

    document.getElementById('export-output').value = out;
  });

  // Init
  renderFipFrame();
  renderVarsTable();
  recalculatePhysical();
  runAudit();
});

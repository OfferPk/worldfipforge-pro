/**
 * WorldFIPForge Pro - WorldFIP (EN 50170-3 / IEC 61158-6) Protocol Framing Engine
 * Implements Producer-Consumer-Distributor (PCD) architecture, Bus Arbitrator (BA)
 * Question-Response cycles, 16-bit Variable Identifiers (VarID), Full FIP / MicroFIP
 * physical layer frame assembly, and CCITT-False CRC-16 Frame Check Sequences.
 */

const WorldFIPEngine = (function () {
  // Physical Delimiters per EN 50170-3 / NFC 46-602
  const PREAMBLE_BYTE = 0x55;  // Alternating bit clock sync (10101010...)
  const START_DELIMITER = 0x1E;// FIP Start Delimiter (SD)
  const END_DELIMITER = 0xE1;  // FIP End Delimiter (ED)

  // Control Byte Frame Types (Control Field / Type d'information)
  const CONTROL_TYPES = {
    0x03: { name: 'ID_DAT (Identifier Question)', desc: 'Broadcast by Bus Arbitrator (BA) to query a variable' },
    0x05: { name: 'RP_DAT (Response Data)', desc: 'Broadcast by producing subscriber with fresh process data' },
    0x04: { name: 'ID_RQ (Message Request)', desc: 'Arbitrator query asking if nodes have aperiodic messages' },
    0x06: { name: 'RP_RQ (Message Aperiodic Response)', desc: 'Node response announcing aperiodic message queued' },
    0x07: { name: 'ID_MSG (Message Transfer)', desc: 'Point-to-point / multicast aperiodic message segment' },
    0x08: { name: 'RP_MSG (Message Acknowledgment)', desc: 'Acknowledgment frame for aperiodic transfer' }
  };

  // Standard WorldFIP Speeds & Physical Constraints per EN 50170-3
  const BUS_SPEEDS = {
    '31.25': { kbps: 31.25, bitTimeUs: 32.0, maxTrunkM: 1900, trUs: 80, name: '31.25 kbps (Process Control)' },
    '1000': { kbps: 1000.0, bitTimeUs: 1.0, maxTrunkM: 1000, trUs: 20, name: '1.0 Mbps (TGV Rail & Nuclear)' },
    '2500': { kbps: 2500.0, bitTimeUs: 0.4, maxTrunkM: 500, trUs: 10, name: '2.5 Mbps (CERN LHC High-Speed)' },
    '5000': { kbps: 5000.0, bitTimeUs: 0.2, maxTrunkM: 200, trUs: 5, name: '5.0 Mbps (Ultra High-Speed Substation)' }
  };

  // Process Variable Status Flags (PDU Status byte: PDU_STATUS)
  // Bit 0: Freshness / Validity (0 = Valid, 1 = Invalid/Stale)
  // Bit 1: Production Error (0 = OK, 1 = Error)
  // Bit 2: Variable Substitution (0 = Normal, 1 = Substituted)
  const PDU_STATUS = {
    VALID_FRESH: 0x00,
    VALID_REFRESHED: 0x01,
    INVALID_STALE: 0x80,
    DEVICE_FAULT: 0x82
  };

  /**
   * Calculates CCITT-False CRC-16 Frame Check Sequence for WorldFIP
   * Polynomial: x^16 + x^12 + x^5 + 1 (0x1021)
   * Init: 0xFFFF, No reflection, Final XOR: 0xFFFF
   */
  function calculateFipCrc16(dataBytes) {
    let crc = 0xFFFF;
    for (const b of dataBytes) {
      crc ^= (b << 8);
      for (let i = 0; i < 8; i++) {
        if (crc & 0x8000) {
          crc = ((crc << 1) ^ 0x1021) & 0xFFFF;
        } else {
          crc = (crc << 1) & 0xFFFF;
        }
      }
    }
    return crc ^ 0xFFFF;
  }

  /**
   * Builds an ID_DAT (Bus Arbitrator Identifier Question Frame)
   * @param {number} varId - 16-bit Variable Identifier (0x0001..0xFFFF)
   */
  function buildIdDatFrame(varId = 0x1001) {
    const safeVarId = varId & 0xFFFF;
    const ctrlByte = 0x03; // ID_DAT
    const varBytes = [(safeVarId >> 8) & 0xFF, safeVarId & 0xFF];

    const coreData = [ctrlByte, ...varBytes];
    const crc = calculateFipCrc16(coreData);
    const crcBytes = [(crc >> 8) & 0xFF, crc & 0xFF];

    const frameBytes = [
      PREAMBLE_BYTE, PREAMBLE_BYTE, // 2-byte Preamble
      START_DELIMITER,              // 0x1E
      ...coreData,
      ...crcBytes,
      END_DELIMITER                 // 0xE1
    ];

    const hexString = frameBytes.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ');

    return {
      frameType: 'ID_DAT',
      controlByte: '0x03',
      varId: safeVarId,
      varIdHex: `0x${safeVarId.toString(16).padStart(4, '0').toUpperCase()}`,
      frameBytes,
      hexString,
      crc: `0x${crc.toString(16).padStart(4, '0').toUpperCase()}`,
      byteLength: frameBytes.length,
      desc: `Bus Arbitrator query for Variable 0x${safeVarId.toString(16).padStart(4, '0').toUpperCase()}`
    };
  }

  /**
   * Builds an RP_DAT (Producer Response Data Frame)
   * @param {number} varId - 16-bit Variable Identifier
   * @param {Array|number} payload - Array of data bytes or single number
   * @param {number} pduStatus - Status byte (0x00 = Fresh/Valid)
   */
  function buildRpDatFrame(varId = 0x1001, payload = [0x01, 0x5E], pduStatus = 0x00) {
    const ctrlByte = 0x05; // RP_DAT
    let data = Array.isArray(payload) ? payload : [payload & 0xFF];
    if (data.length > 128) {
      data = data.slice(0, 128); // Standard FIP PDU size limit
    }

    const coreData = [ctrlByte, pduStatus & 0xFF, ...data];
    const crc = calculateFipCrc16(coreData);
    const crcBytes = [(crc >> 8) & 0xFF, crc & 0xFF];

    const frameBytes = [
      PREAMBLE_BYTE, PREAMBLE_BYTE,
      START_DELIMITER,
      ...coreData,
      ...crcBytes,
      END_DELIMITER
    ];

    const hexString = frameBytes.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ');

    return {
      frameType: 'RP_DAT',
      controlByte: '0x05',
      varId: varId & 0xFFFF,
      varIdHex: `0x${(varId & 0xFFFF).toString(16).padStart(4, '0').toUpperCase()}`,
      pduStatus: `0x${(pduStatus & 0xFF).toString(16).padStart(2, '0').toUpperCase()}`,
      dataBytesCount: data.length,
      frameBytes,
      hexString,
      crc: `0x${crc.toString(16).padStart(4, '0').toUpperCase()}`,
      byteLength: frameBytes.length,
      desc: `Producer response containing ${data.length} bytes for Var 0x${(varId & 0xFFFF).toString(16).padStart(4, '0').toUpperCase()}`
    };
  }

  /**
   * Dissects an incoming WorldFIP hex stream
   */
  function dissectFipFrame(hexStr) {
    const cleanHex = hexStr.replace(/[^0-9a-fA-F]/g, '');
    const bytes = [];
    for (let i = 0; i < cleanHex.length; i += 2) {
      bytes.push(parseInt(cleanHex.substr(i, 2), 16));
    }

    if (bytes.length < 6) {
      throw new Error(`Frame too short for WorldFIP dissection (${bytes.length} bytes, minimum 6 required)`);
    }

    const sdIdx = bytes.indexOf(START_DELIMITER);
    const edIdx = bytes.lastIndexOf(END_DELIMITER);

    if (sdIdx === -1 || edIdx === -1 || edIdx <= sdIdx + 3) {
      throw new Error("Invalid WorldFIP framing: Missing Start (0x1E) or End (0xE1) delimiter.");
    }

    const coreData = bytes.slice(sdIdx + 1, edIdx - 2);
    const receivedCrc = (bytes[edIdx - 2] << 8) | bytes[edIdx - 1];
    const computedCrc = calculateFipCrc16(coreData);
    const isCrcValid = (receivedCrc === computedCrc);

    const ctrl = coreData[0];
    const ctrlMeta = CONTROL_TYPES[ctrl] || { name: 'Unknown Control', desc: '' };

    let details = {};
    if (ctrl === 0x03 && coreData.length >= 3) {
      // ID_DAT: Control (1) + VarID (2)
      const varId = (coreData[1] << 8) | coreData[2];
      details = {
        frameKind: 'ID_DAT',
        varId: `0x${varId.toString(16).padStart(4, '0').toUpperCase()}`,
        varIdDecimal: varId
      };
    } else if (ctrl === 0x05 && coreData.length >= 2) {
      // RP_DAT: Control (1) + Status (1) + Data (N)
      const status = coreData[1];
      const payload = coreData.slice(2);
      details = {
        frameKind: 'RP_DAT',
        statusByte: `0x${status.toString(16).padStart(2, '0').toUpperCase()}`,
        payloadLength: payload.length,
        payloadHex: payload.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ')
      };
    }

    return {
      controlByte: `0x${ctrl.toString(16).padStart(2, '0').toUpperCase()}`,
      controlName: ctrlMeta.name,
      controlDesc: ctrlMeta.desc,
      details,
      receivedCrc: `0x${receivedCrc.toString(16).padStart(4, '0').toUpperCase()}`,
      computedCrc: `0x${computedCrc.toString(16).padStart(4, '0').toUpperCase()}`,
      isCrcValid,
      totalLength: bytes.length
    };
  }

  return {
    PREAMBLE_BYTE,
    START_DELIMITER,
    END_DELIMITER,
    CONTROL_TYPES,
    BUS_SPEEDS,
    PDU_STATUS,
    calculateFipCrc16,
    buildIdDatFrame,
    buildRpDatFrame,
    dissectFipFrame
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = WorldFIPEngine;
}

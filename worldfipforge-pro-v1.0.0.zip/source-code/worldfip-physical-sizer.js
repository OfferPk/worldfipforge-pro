/**
 * WorldFIPForge Pro - Physical Layer Sizer & Wire Line Budget Engine
 * Calculates shielded twisted pair (150-ohm characteristic impedance) attenuation,
 * maximum trunk distances across baud rates (31.25k, 1M, 2.5M, 5M), drop lengths (<= 10m),
 * and dual 150-ohm line termination requirements.
 */

const WorldFIPPhysicalSizer = (function () {
  // Physical Layer Guidelines per EN 50170-3 / NFC 46-604
  const PHY_PROFILES = {
    '31.25': {
      speedLabel: '31.25 kbps',
      baudKbps: 31.25,
      maxTrunkM: 1900,
      maxDropM: 10.0,
      maxStationsPerSegment: 32,
      cableType: 'Shielded Twisted Pair (150 Ω)',
      nominalVelocity: 0.67 // 67% c -> ~5 ns/m
    },
    '1000': {
      speedLabel: '1.0 Mbps (Standard TGV / Nuclear)',
      baudKbps: 1000.0,
      maxTrunkM: 1000,
      maxDropM: 10.0,
      maxStationsPerSegment: 32,
      cableType: 'Shielded Twisted Pair (150 Ω)',
      nominalVelocity: 0.67
    },
    '2500': {
      speedLabel: '2.5 Mbps (CERN High-Speed Particle Accelerator)',
      baudKbps: 2500.0,
      maxTrunkM: 500,
      maxDropM: 5.0,
      maxStationsPerSegment: 32,
      cableType: 'Shielded Twisted Pair (150 Ω)',
      nominalVelocity: 0.67
    },
    '5000': {
      speedLabel: '5.0 Mbps (Substation Ultra-High-Speed)',
      baudKbps: 5000.0,
      maxTrunkM: 200,
      maxDropM: 2.0,
      maxStationsPerSegment: 16,
      cableType: 'Twinaxial / Low-Loss High-Speed',
      nominalVelocity: 0.70
    }
  };

  /**
   * Sizing calculations for a physical network segment
   * @param {number} trunkLengthM - Physical trunk distance in meters
   * @param {Array} stations - Array of station objects: [{ stationId, name, dropLengthM }]
   * @param {string} speedKey - '31.25' | '1000' | '2500' | '5000'
   */
  function evaluatePhysicalSegment(trunkLengthM, stations, speedKey = '1000') {
    const profile = PHY_PROFILES[speedKey] || PHY_PROFILES['1000'];
    const totalStations = stations.length;

    let totalDropM = 0;
    let longestDropM = 0;

    stations.forEach(s => {
      const drop = parseFloat(s.dropLengthM) || 0.0;
      totalDropM += drop;
      if (drop > longestDropM) longestDropM = drop;
    });

    const totalCableLengthM = trunkLengthM + totalDropM;

    // Cable propagation delay (5.0 ns per meter)
    const oneWayPropagationUs = parseFloat(((totalCableLengthM * 5.0) / 1000.0).toFixed(3));
    const roundTripPropagationUs = parseFloat((oneWayPropagationUs * 2.0).toFixed(3));

    // Attenuation estimation (~15 dB max loss budget)
    const dbLossPerKm = (profile.baudKbps >= 2500) ? 22.0 : (profile.baudKbps >= 1000 ? 12.0 : 3.0);
    const estimatedLossDb = parseFloat(((totalCableLengthM / 1000.0) * dbLossPerKm).toFixed(2));

    return {
      profile,
      speedKey,
      trunkLengthM,
      totalCableLengthM,
      longestDropM,
      totalDropM,
      totalStations,
      oneWayPropagationUs,
      roundTripPropagationUs,
      estimatedLossDb,
      isTrunkCompliant: trunkLengthM <= profile.maxTrunkM,
      isDropCompliant: longestDropM <= profile.maxDropM,
      isStationCountCompliant: totalStations <= profile.maxStationsPerSegment,
      isLossCompliant: estimatedLossDb <= 15.0
    };
  }

  return {
    PHY_PROFILES,
    evaluatePhysicalSegment
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = WorldFIPPhysicalSizer;
}

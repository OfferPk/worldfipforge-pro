/**
 * WorldFIPForge Pro - Bus Arbitrator (BA) Elementary & Macrocycle Scheduler
 * Sequences periodic exchange windows for cyclic variables, turnaround silence
 * windows (Tr/Ta), aperiodic message slots, and calculates bus load & jitter.
 */

const WorldFIPScheduler = (function () {
  /**
   * Generates a deterministic Macrocycle schedule of Elementary Cycles (EC).
   * @param {Array} variables - List of cyclic variables:
   *   [
   *     { varId: 0x1001, name: 'Train Speed (Kmh)', periodMs: 10, producer: 'Traction Unit 1', dataBytes: 4 },
   *     { varId: 0x1002, name: 'Brake Cylinder Pressure', periodMs: 10, producer: 'Brake Unit 1', dataBytes: 4 },
   *     { varId: 0x2001, name: 'Pantograph Position', periodMs: 20, producer: 'High-Voltage Unit', dataBytes: 2 },
   *     { varId: 0x3001, name: 'HVAC Temperature', periodMs: 50, producer: 'Carriage HVAC', dataBytes: 8 }
   *   ]
   * @param {number} elementaryCycleMs - Base tick period (e.g. 5ms or 10ms)
   * @param {number} baudRateKbps - 1000 (1.0 Mbps), 2500 (2.5 Mbps), 31.25, etc.
   */
  function buildMacrocycle(variables, elementaryCycleMs = 10, baudRateKbps = 1000) {
    const bitTimeUs = 1000.0 / baudRateKbps;
    const trSilenceUs = baudRateKbps >= 1000 ? 20.0 : 80.0; // Response turnaround time

    // Calculate frame durations
    // ID_DAT: 2 bytes preamble + 1 SD + 1 ctrl + 2 varId + 2 CRC + 1 ED = 9 bytes = 72 bits
    const idDatBits = 9 * 8;
    const idDatDurationUs = idDatBits * bitTimeUs;

    const varTimings = variables.map(v => {
      const dataLen = Math.min(128, Math.max(1, v.dataBytes || 2));
      // RP_DAT: 2 preamble + 1 SD + 1 ctrl + 1 status + dataLen + 2 CRC + 1 ED = 8 + dataLen bytes
      const rpDatBytes = 8 + dataLen;
      const rpDatBits = rpDatBytes * 8;
      const rpDatDurationUs = rpDatBits * bitTimeUs;

      // Full transaction = ID_DAT + Tr + RP_DAT + Tr
      const transactionUs = idDatDurationUs + trSilenceUs + rpDatDurationUs + trSilenceUs;
      const transactionMs = parseFloat((transactionUs / 1000.0).toFixed(3));

      return {
        varId: v.varId,
        varIdHex: `0x${v.varId.toString(16).padStart(4, '0').toUpperCase()}`,
        name: v.name || `Var 0x${v.varId.toString(16).toUpperCase()}`,
        periodMs: v.periodMs || elementaryCycleMs,
        producer: v.producer || 'Station 1',
        dataBytes: dataLen,
        transactionUs: Math.round(transactionUs),
        transactionMs
      };
    });

    // Macrocycle duration is LCM of variable periods (capped at max 100ms)
    const periods = variables.map(v => v.periodMs || elementaryCycleMs);
    const macrocycleMs = Math.max(elementaryCycleMs, Math.max(...periods, elementaryCycleMs));
    const numElementaryCycles = Math.max(1, Math.round(macrocycleMs / elementaryCycleMs));

    // Allocate variables into Elementary Cycles (EC 1..N)
    const elementaryCycles = [];
    for (let ec = 0; ec < numElementaryCycles; ec++) {
      const ecTimeOffsetMs = ec * elementaryCycleMs;
      const ecVars = [];
      let ecPeriodicTimeUs = 0;

      varTimings.forEach(vt => {
        const intervalEc = Math.max(1, Math.round(vt.periodMs / elementaryCycleMs));
        if (ec % intervalEc === 0) {
          ecVars.push(vt);
          ecPeriodicTimeUs += vt.transactionUs;
        }
      });

      const ecPeriodicTimeMs = parseFloat((ecPeriodicTimeUs / 1000.0).toFixed(3));
      const aperiodicSlotMs = parseFloat(Math.max(0, elementaryCycleMs - ecPeriodicTimeMs).toFixed(3));
      const ecLoadPercent = parseFloat(((ecPeriodicTimeMs / elementaryCycleMs) * 100.0).toFixed(1));

      elementaryCycles.push({
        ecIndex: ec + 1,
        timeOffsetMs: ecTimeOffsetMs,
        variables: ecVars,
        periodicDurationMs: ecPeriodicTimeMs,
        aperiodicSlotMs,
        loadPercent: ecLoadPercent,
        isOverloaded: ecPeriodicTimeMs > elementaryCycleMs
      });
    }

    const avgLoadPercent = parseFloat((elementaryCycles.reduce((s, c) => s + c.loadPercent, 0) / elementaryCycles.length).toFixed(1));
    const maxLoadPercent = Math.max(...elementaryCycles.map(c => c.loadPercent));

    return {
      macrocycleMs,
      elementaryCycleMs,
      numElementaryCycles,
      baudRateKbps,
      varTimings,
      elementaryCycles,
      summary: {
        totalVariables: variables.length,
        avgLoadPercent,
        maxLoadPercent,
        isSchedulable: maxLoadPercent <= 100.0,
        aperiodicHeadroomPercent: parseFloat((100.0 - avgLoadPercent).toFixed(1))
      }
    };
  }

  return {
    buildMacrocycle
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = WorldFIPScheduler;
}
